#include <inttypes.h>
#include <stdio.h>

#define FRACTION (1 << 14)

int floatToFloat(int f1, int f2, char op);
int intToFloat(int i, int f, char op);
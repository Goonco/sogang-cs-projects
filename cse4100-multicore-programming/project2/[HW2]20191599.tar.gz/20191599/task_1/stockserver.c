#include "csapp.h"
#define MAXARGS 3

typedef struct
{
    int maxfd;        // Largest descriptor (first parameter for select)
    fd_set read_set;  // Set of all active descriptors
    fd_set ready_set; // Set of descriptors for reading
    int nready;       // Num of ready descriptor

    int maxi; // Largest index of clientfd
    int clientfd[FD_SETSIZE];
    rio_t clientrio[FD_SETSIZE];
} pool;

int byte_cnt = 0; // Total bytes received by server?
int listenfd;     // Globalizationed listenfd

void init_pool(int listenfd, pool *p);
void add_client(int clientfd, pool *p);
void check_client(pool *p);
void echo(int connfd);

#define MAXID 101
typedef struct Stock
{
    int ID;
    int left_stock;
    int price;
    // int readcnt;
    // sem_t mutex;
    struct Stock *left;
    struct Stock *right;
} Stock;
Stock *root;

Stock *createItem(int ID, int left_stock, int price);
void insertStock(Stock *newStock);
void parseline(char *buf, char **argv);
void init();

FILE *fp;
char filesrc[1024];

// Handle Commands
void showStock(int connfd);
void buyStock(int connfd, int targetID, int num);
void sellStock(int connfd, int targetID, int num);
void closeClient(int connfd, int i, pool *p);
void updateData();

// Time Calculate
struct timeval start_time, end_time;
#define CLIENTNUM 100
int clientNum = 1;
int flag = 1;

int main(int argc, char **argv)
{
    // ⓐ Verify Argument - Port Number
    if (argc != 2)
    {
        fprintf(stderr, "usage: %s <port>\n", argv[0]);
        exit(0);
    }

    init();

    // ⓑ Variable Declaration
    int connfd;
    socklen_t clientlen;
    struct sockaddr_storage clientaddr; /* Enough space for any address */ // line:netp:echoserveri:sockaddrstorage
    char client_hostname[MAXLINE], client_port[MAXLINE];                   // ?
    static pool pool;

    // ⓒ Get listenfd
    listenfd = Open_listenfd(argv[1]);
    init_pool(listenfd, &pool);

    while (1)
    {
        if (!clientNum)
        {
            flag = 1;
            gettimeofday(&end_time, NULL);
            long sec = end_time.tv_sec - start_time.tv_sec;
            long ms = end_time.tv_usec - start_time.tv_usec;
            double elapsed_time = sec + ms / 1000000.0;
            printf("Elapsed Time: %.6f seconds\n", elapsed_time);
        }

        // ⓓ Wait for event
        pool.ready_set = pool.read_set;
        pool.nready = Select(pool.maxfd + 1, &pool.ready_set, NULL, NULL, NULL);

        if (flag)
        {
            flag = 0;
            clientNum = CLIENTNUM;
            gettimeofday(&start_time, NULL);
        }

        // ⓔ Handle connection event
        if (FD_ISSET(listenfd, &pool.ready_set))
        {
            clientlen = sizeof(struct sockaddr_storage);
            connfd = Accept(listenfd, (SA *)&clientaddr, &clientlen);
            Getnameinfo((SA *)&clientaddr, clientlen, client_hostname, MAXLINE,
                        client_port, MAXLINE, 0);
            printf("Connected to (%s, %s)\n", client_hostname, client_port);
            add_client(connfd, &pool);
        }

        // ⓕ Handle client event
        check_client(&pool);
    }
    exit(0);
}

void init_pool(int listenfd, pool *p)
{
    // No connected descriptors
    p->maxi = -1;
    for (int i = 0; i < FD_SETSIZE; i++)
        p->clientfd[i] = -1;
    FD_ZERO(&p->read_set);

    // listenfd added for the set
    p->maxfd = listenfd;
    FD_SET(listenfd, &p->read_set);
}

void add_client(int clientfd, pool *p)
{
    int i;
    for (i = 0; i < FD_SETSIZE; i++)
    {
        if (p->clientfd[i] < 0)
        {
            // printf("Connection Successed\n");
            p->clientfd[i] = clientfd;
            FD_SET(clientfd, &p->read_set);
            Rio_readinitb(&p->clientrio[i], clientfd); // clientfd에 대해 사용할 rio 구조체 초기화

            p->maxfd = p->maxfd > clientfd ? p->maxfd : clientfd;
            p->maxi = p->maxi > i ? p->maxi : i;
            break;
        }
    }

    // Connection event handling complete
    p->nready--;

    // No emptyslot for a client
    if (i == FD_SETSIZE)
        app_error("add_client error : Too many clients");
}

void check_client(pool *p)
{
    int i, connfd, n;
    rio_t rio;
    char buf[MAXLINE] = {
        0,
    };

    for (i = 0; (p->nready > 0) && (i <= p->maxi); i++)
    {
        if (p->clientfd[i] < 0)
            continue;

        connfd = p->clientfd[i];
        rio = p->clientrio[i];
        if (FD_ISSET(connfd, &p->ready_set))
        {
            // Client event handling complete
            p->nready--;

            if ((n = Rio_readlineb(&rio, buf, MAXLINE)) != 0)
            {
                byte_cnt += n;
                printf("Server received %d (%d total) bytes on fd %d\n", n, byte_cnt, connfd);

                char *argv[MAXARGS];
                parseline(buf, argv);

                // Stock Server
                if (!strcmp(argv[0], "show"))
                    showStock(connfd);
                else if (!strcmp(argv[0], "buy"))
                    buyStock(connfd, atoi(argv[1]), atoi(argv[2]));
                else if (!strcmp(argv[0], "sell"))
                    sellStock(connfd, atoi(argv[1]), atoi(argv[2]));
                else if (!strcmp(argv[0], "exit"))
                    closeClient(connfd, i, p);
                else
                {
                    char str[] = "Invalid Command\n";
                    Rio_writen(connfd, str, MAXLINE);
                }
            }
            else
                closeClient(connfd, i, p);
        }
    }
}

void closeClient(int connfd, int i, pool *p)
{
    clientNum--;
    Rio_writen(connfd, "", MAXLINE);

    Close(connfd);
    FD_CLR(connfd, &p->read_set);
    p->clientfd[i] = -1;

    if (i == p->maxi)
        p->maxi--;
    if (connfd == p->maxfd)
    {
        p->maxfd = listenfd;
        for (int j = 0; j <= p->maxi; j++)
        {
            if (p->clientfd[j] > p->maxfd)
                p->maxfd = p->clientfd[j];
        }
    }
}

Stock *createItem(int ID, int left_stock, int price)
{
    Stock *newStock = (Stock *)malloc(sizeof(Stock));
    newStock->ID = ID;
    newStock->left_stock = left_stock;
    newStock->price = price;

    newStock->left = NULL;
    newStock->right = NULL;
    return newStock;
}

void init()
{
    // opening the file
    if (getcwd(filesrc, sizeof(filesrc)) == NULL)
    {
        perror("getcwd error");
        exit(EXIT_FAILURE);
    }
    strcat(filesrc, "/stock.txt");

    root = NULL;
    fp = fopen(filesrc, "a");
    fclose(fp);

    // setting stock binary tree
    fp = fopen(filesrc, "r");
    while (!feof(fp))
    {
        char stockData[1024];
        if (!fgets(stockData, MAXLINE, fp)) // 마지막 중복 출력 처리
            break;

        char *endptr;
        char *token = strtok(stockData, " ");
        int id = strtol(token, &endptr, 10);

        token = strtok(NULL, " ");
        int stock = strtol(token, &endptr, 10);

        token = strtok(NULL, " ");
        int price = strtol(token, &endptr, 10);

        Stock *newStock = createItem(id, stock, price);
        insertStock(newStock);
    }
    fclose(fp);

    signal(SIGINT, updateData);
    return;
}

void insertStock(Stock *newStock)
{
    // Using inorder traverse
    if (root == NULL)
        root = newStock;
    else
    {
        Stock *stack[MAXID];
        int top = -1;
        stack[++top] = root;

        while (top != -1)
        {
            Stock *iter = stack[top--];

            if (iter->left != NULL)
                stack[++top] = iter->left;
            else
            {
                iter->left = newStock;
                break;
            }
            if (iter->right != NULL)
                stack[++top] = iter->right;
            else
            {
                iter->right = newStock;
                break;
            }
        }
    }
    return;
}

void showStock(int connfd)
{
    if (root == NULL) // No Stock Existing
        return;
    else
    {
        Stock *stack[MAXID];
        int top = -1;
        stack[++top] = root;

        char str[MAXLINE] = {
            0,
        };
        while (top != -1)
        {
            Stock *iter = stack[top--];
            char buf[RIO_BUFSIZE];
            sprintf(buf, "%d %d %d\n", iter->ID, iter->left_stock, iter->price);
            strcat(str, buf);

            if (iter->left != NULL)
                stack[++top] = iter->left;

            if (iter->right != NULL)
                stack[++top] = iter->right;
        }

        Rio_writen(connfd, str, MAXLINE);
    }

    return;
}

void buyStock(int connfd, int targetID, int num)
{
    if (root == NULL) // No Stock Existing
        return;
    else
    {
        Stock *stack[MAXID];
        int top = -1;
        stack[++top] = root;

        while (top != -1)
        {
            Stock *iter = stack[top--];

            if (iter->ID == targetID)
            {
                if (iter->left_stock >= num)
                {
                    iter->left_stock -= num;
                    char str[] = "[buy] success\n";
                    Rio_writen(connfd, str, MAXLINE);
                }
                else
                {
                    char str[] = "Not enough left stock\n";
                    Rio_writen(connfd, str, MAXLINE);
                }
                break;
            }

            if (iter->left != NULL)
                stack[++top] = iter->left;

            if (iter->right != NULL)
                stack[++top] = iter->right;
        }
    }

    return;
}

void sellStock(int connfd, int targetID, int num)
{
    if (root == NULL) // No Stock Existing
        return;
    else
    {
        Stock *stack[MAXID];
        int top = -1;
        stack[++top] = root;

        while (top != -1)
        {
            Stock *iter = stack[top--];

            if (iter->ID == targetID)
            {
                iter->left_stock += num;
                char str[] = "[sell] success\n";
                Rio_writen(connfd, str, MAXLINE);
                break;
            }

            if (iter->left != NULL)
                stack[++top] = iter->left;

            if (iter->right != NULL)
                stack[++top] = iter->right;
        }
    }

    return;
}

void updateData()
{
    fp = fopen(filesrc, "w");
    if (root != NULL)
    {
        Stock *stack[MAXID];
        int top = -1;
        stack[++top] = root;

        while (top != -1)
        {
            Stock *iter = stack[top--];
            char buf[RIO_BUFSIZE];
            sprintf(buf, "%d %d %d\n", iter->ID, iter->left_stock, iter->price);
            fputs(buf, fp);

            if (iter->left != NULL)
                stack[++top] = iter->left;

            if (iter->right != NULL)
                stack[++top] = iter->right;
        }
    }
    fclose(fp);
    exit(0);
}

void parseline(char *buf, char **argv)
{
    char *delim; /* Points to first space delimiter */
    int argc;    /* Number of args */

    buf[strlen(buf) - 1] = ' ';   /* Replace trailing '\n' with space */
    while (*buf && (*buf == ' ')) /* Ignore leading spaces */
        buf++;

    /* Build the argv list */
    argc = 0;

    while ((delim = strchr(buf, ' ')))
    {

        argv[argc++] = buf;
        *delim = '\0';
        buf = delim + 1;
        while (*buf && (*buf == ' '))
            buf++;
    }
    argv[argc] = NULL;
}
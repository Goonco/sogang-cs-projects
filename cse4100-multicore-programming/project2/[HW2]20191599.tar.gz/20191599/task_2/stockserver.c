#include "csapp.h"
#define MAXARGS 3

typedef struct
{
    int *buf;
    int n;
    int front;
    int rear;
    sem_t mutex;
    sem_t slots;
    sem_t items;
} sbuf_t;
sbuf_t sbuf;

void sbuf_init(sbuf_t *sp, int n);
void sbuf_insert(sbuf_t *sp, int connfd);
int sbuf_remove(sbuf_t *sp);

int byte_cnt = 0; // Total bytes received by server
int listenfd;     // Globalizationed listenfd

void echo(int connfd);

#define MAXID 101    // Stock Max ID
#define NTHREADS 100 // Max Client
#define SBUFSIZE 100

typedef struct Stock
{
    int ID;
    int left_stock;
    int price;

    struct Stock *left;
    struct Stock *right;

    int readcnt;
    sem_t mutex;
    sem_t w;
} Stock;
Stock *root;

Stock *createItem(int ID, int left_stock, int price);
void parseline(char *buf, char **argv);
void init();

FILE *fp;
char filesrc[1024];

// Handle Commands
void insertStock(Stock *newStock);
void showStock(int connfd);
void buyStock(int connfd, int targetID, int num);
void sellStock(int connfd, int targetID, int num);
void updateData();

void *thread(void *vargp);

// Time Calculate
struct timeval start_time, end_time;
sem_t timeMut;
#define CLIENTNUM 100
int clientNum;
int flag = 1;

int main(int argc, char **argv)
{
    // ⓐ Verify Argument - Port Number
    if (argc != 2)
    {
        fprintf(stderr, "usage: %s <port>\n", argv[0]);
        exit(0);
    }

    init();

    // ⓑ Variable Declaration
    int *connfd;
    socklen_t clientlen;
    struct sockaddr_storage clientaddr;
    char client_hostname[MAXLINE], client_port[MAXLINE];

    // ⓒ Get listenfd
    listenfd = Open_listenfd(argv[1]);
    while (1)
    {
        clientlen = sizeof(struct sockaddr_storage);
        connfd = Malloc(sizeof(int));
        *connfd = Accept(listenfd, (SA *)&clientaddr, &clientlen);

        if (flag)
        {
            flag = 0;
            clientNum = CLIENTNUM;
            gettimeofday(&start_time, NULL);
        }

        Getnameinfo((SA *)&clientaddr, clientlen, client_hostname, MAXLINE,
                    client_port, MAXLINE, 0);
        printf("Connected to (%s, %s)\n", client_hostname, client_port);
        sbuf_insert(&sbuf, *connfd);
    }
    exit(0);
}

void *thread(void *vargp)
{
    // printf("Connection Successed\n");
    Pthread_detach(pthread_self());
    Free(vargp);

    while (1)
    {
        int connfd = sbuf_remove(&sbuf);
        // printf("Connection Successed\n");
        int n;
        char buf[MAXLINE];
        rio_t rio;
        Rio_readinitb(&rio, connfd);
        while ((n = Rio_readlineb(&rio, buf, MAXLINE)) != 0)
        {
            byte_cnt += n;
            printf("Server received %d (%d total) bytes on fd %d\n", n, byte_cnt, connfd);

            char *argv[MAXARGS];
            parseline(buf, argv);

            // Stock Server
            if (!strcmp(argv[0], "show"))
                showStock(connfd);
            else if (!strcmp(argv[0], "buy"))
                buyStock(connfd, atoi(argv[1]), atoi(argv[2]));
            else if (!strcmp(argv[0], "sell"))
                sellStock(connfd, atoi(argv[1]), atoi(argv[2]));
            else if (!strcmp(argv[0], "exit"))
                break;
            else
            {
                char str[] = "Invalid Command\n";
                Rio_writen(connfd, str, MAXLINE);
            }
        }

        P(&timeMut);
        clientNum--;
        if (!flag && !clientNum)
        {
            flag = 1;
            gettimeofday(&end_time, NULL);
            long sec = end_time.tv_sec - start_time.tv_sec;
            long ms = end_time.tv_usec - start_time.tv_usec;
            double elapsed_time = sec + ms / 1000000.0;
            printf("Elapsed Time: %.6f seconds\n", elapsed_time);
        }
        V(&timeMut);

        Close(connfd);
    }

    return NULL;
}

void init()
{
    // opening the file
    if (getcwd(filesrc, sizeof(filesrc)) == NULL)
    {
        perror("getcwd error");
        exit(EXIT_FAILURE);
    }
    strcat(filesrc, "/stock.txt");

    root = NULL;
    fp = fopen(filesrc, "a");
    fclose(fp);

    // setting stock binary tree
    fp = fopen(filesrc, "r");
    while (!feof(fp))
    {
        char stockData[1024];
        if (!fgets(stockData, MAXLINE, fp)) // 마지막 중복 출력 처리
            break;

        char *endptr;
        char *token = strtok(stockData, " ");
        int id = strtol(token, &endptr, 10);

        token = strtok(NULL, " ");
        int stock = strtol(token, &endptr, 10);

        token = strtok(NULL, " ");
        int price = strtol(token, &endptr, 10);

        Stock *newStock = createItem(id, stock, price);
        insertStock(newStock);
    }
    fclose(fp);

    // Update Data to stock.txt when server closed
    signal(SIGINT, updateData);

    // Create working threads
    pthread_t tid;
    for (int i = 0; i < NTHREADS; i++)
        Pthread_create(&tid, NULL, thread, NULL);

    // Initialize sbuf
    sbuf_init(&sbuf, SBUFSIZE);

    // For Time Calculate
    Sem_init(&timeMut, 0, 1);
    return;
}

void sbuf_init(sbuf_t *sp, int n)
{
    sp->buf = Calloc(n, sizeof(int));
    sp->n = n;
    sp->front = sp->rear = 0;
    Sem_init(&sp->mutex, 0, 1);
    Sem_init(&sp->slots, 0, n);
    Sem_init(&sp->items, 0, 0);
}

void sbuf_insert(sbuf_t *sp, int connfd)
{
    P(&sp->slots); // Slots Decr
    P(&sp->mutex);
    sp->buf[(++sp->rear) % (sp->n)] = connfd;
    V(&sp->mutex);
    V(&sp->items); // Items Incr
}

int sbuf_remove(sbuf_t *sp)
{
    P(&sp->items); // Items Decr
    P(&sp->mutex);
    int connfd = sp->buf[(++sp->front) % (sp->n)];
    V(&sp->mutex);
    V(&sp->slots); // Slots Incr
    return connfd;
}

Stock *createItem(int ID, int left_stock, int price)
{
    Stock *newStock = (Stock *)malloc(sizeof(Stock));
    newStock->ID = ID;
    newStock->left_stock = left_stock;
    newStock->price = price;

    newStock->left = NULL;
    newStock->right = NULL;

    newStock->readcnt = 0;
    Sem_init(&newStock->mutex, 0, 1);
    Sem_init(&newStock->w, 0, 1);
    return newStock;
}

void insertStock(Stock *newStock)
{
    // Using inorder traverse
    if (root == NULL)
        root = newStock;
    else
    {
        Stock *stack[MAXID];
        int top = -1;
        stack[++top] = root;

        while (top != -1)
        {
            Stock *iter = stack[top--];

            if (iter->left != NULL)
                stack[++top] = iter->left;
            else
            {
                iter->left = newStock;
                break;
            }
            if (iter->right != NULL)
                stack[++top] = iter->right;
            else
            {
                iter->right = newStock;
                break;
            }
        }
    }
    return;
}

void showStock(int connfd)
{
    if (root == NULL) // No Stock Existing
        return;
    else
    {
        Stock *stack[MAXID];
        int top = -1;
        stack[++top] = root;

        char str[MAXLINE] = {
            0,
        };
        while (top != -1)
        {
            Stock *iter = stack[top--];

            P(&iter->mutex);
            iter->readcnt++;
            if (iter->readcnt == 1)
                P(&iter->w);
            V(&iter->mutex);

            char buf[RIO_BUFSIZE];
            sprintf(buf, "%d %d %d\n", iter->ID, iter->left_stock, iter->price);
            strcat(str, buf);

            P(&iter->mutex);
            iter->readcnt--;
            if (iter->readcnt == 0)
                V(&iter->w);
            V(&iter->mutex);

            if (iter->left != NULL)
                stack[++top] = iter->left;

            if (iter->right != NULL)
                stack[++top] = iter->right;
        }

        Rio_writen(connfd, str, MAXLINE);
    }

    return;
}

void buyStock(int connfd, int targetID, int num)
{

    if (root == NULL) // No Stock Existing
        return;
    else
    {
        Stock *stack[MAXID];
        int top = -1;
        stack[++top] = root;

        while (top != -1)
        {
            Stock *iter = stack[top--];

            if (iter->ID == targetID)
            {
                P(&iter->w);
                if (iter->left_stock >= num)
                {
                    iter->left_stock -= num;
                    char str[] = "[buy] success\n";
                    Rio_writen(connfd, str, MAXLINE);
                }
                else
                {
                    char str[] = "Not enough left stock\n";
                    Rio_writen(connfd, str, MAXLINE);
                }
                V(&iter->w);
                break;
            }

            if (iter->left != NULL)
                stack[++top] = iter->left;

            if (iter->right != NULL)
                stack[++top] = iter->right;
        }
    }

    return;
}

void sellStock(int connfd, int targetID, int num)
{
    if (root == NULL) // No Stock Existing
        return;
    else
    {
        Stock *stack[MAXID];
        int top = -1;
        stack[++top] = root;

        while (top != -1)
        {
            Stock *iter = stack[top--];

            if (iter->ID == targetID)
            {
                P(&iter->w);
                iter->left_stock += num;
                char str[] = "[sell] success\n";
                Rio_writen(connfd, str, MAXLINE);
                V(&iter->w);
                break;
            }

            if (iter->left != NULL)
                stack[++top] = iter->left;

            if (iter->right != NULL)
                stack[++top] = iter->right;
        }
    }

    return;
}

void updateData()
{
    fp = fopen(filesrc, "w");
    if (root != NULL)
    {
        Stock *stack[MAXID];
        int top = -1;
        stack[++top] = root;

        while (top != -1)
        {
            Stock *iter = stack[top--];
            char buf[RIO_BUFSIZE];
            sprintf(buf, "%d %d %d\n", iter->ID, iter->left_stock, iter->price);
            fputs(buf, fp);

            if (iter->left != NULL)
                stack[++top] = iter->left;

            if (iter->right != NULL)
                stack[++top] = iter->right;
        }
    }
    fclose(fp);
    exit(0);
}

void parseline(char *buf, char **argv)
{
    char *delim; /* Points to first space delimiter */
    int argc;    /* Number of args */

    buf[strlen(buf) - 1] = ' ';   /* Replace trailing '\n' with space */
    while (*buf && (*buf == ' ')) /* Ignore leading spaces */
        buf++;

    /* Build the argv list */
    argc = 0;

    while ((delim = strchr(buf, ' ')))
    {

        argv[argc++] = buf;
        *delim = '\0';
        buf = delim + 1;
        while (*buf && (*buf == ' '))
            buf++;
    }
    argv[argc] = NULL;
}
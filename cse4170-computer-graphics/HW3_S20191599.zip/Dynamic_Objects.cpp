#define _CRT_SECURE_NO_WARNINGS
#include "Scene_Definitions.h"

glm::vec2 catmullRom(const glm::vec2& p0, const glm::vec2& p1, const glm::vec2& p2, const glm::vec2& p3, float t) {
	float t2 = t * t;
	float t3 = t2 * t;
	return 0.5f * ((2.0f * p1) +
		(-p0 + p2) * t +
		(2.0f * p0 - 5.0f * p1 + 4.0f * p2 - p3) * t2 +
		(-p0 + 3.0f * p1 - 3.0f * p2 + p3) * t3);
}


void Spider_D::define_object() {
#define N_SPIDER_FRAMES 16
	glm::mat4* cur_MM;
	Material* cur_material;
	flag_valid = true;

	for (int i = 0; i < N_SPIDER_FRAMES; i++) {
		object_frames.emplace_back();
		sprintf(object_frames[i].filename, "Data/dynamic_objects/spider/spider_vnt_%d%d.geom", i / 10, i % 10);
		object_frames[i].n_fields = 8;
		object_frames[i].front_face_mode = GL_CW;
		object_frames[i].prepare_geom_of_static_object();

		object_frames[i].instances.emplace_back();
		cur_MM = &(object_frames[i].instances.back().ModelMatrix);
		//*cur_MM = glm::rotate(*cur_MM, 90.0f * TO_RADIAN,glm::vec3(0.0f, 1.0f, 0.0f));
		//*cur_MM = glm::scale(*cur_MM, glm::vec3(3.0f, -3.0f, 3.0f));
		cur_material = &(object_frames[i].instances.back().material);
		cur_material->emission = glm::vec4(255.0f, 0.0f, 0.0f, 1.0f);
		cur_material->ambient = glm::vec4(255.0f, 0.0f, 0.0f, 1.0f);
		cur_material->diffuse = glm::vec4(255.0f, 0.0f, 0.0f, 1.0f);
		cur_material->specular = glm::vec4(255.0f, 0.0f, 0.0f, 1.0f);
		cur_material->exponent = 128.0f * 0.21794872f;
	}
}

void Extra_Spider::define_object() {
#define N_SPIDER_FRAMES 16
	glm::mat4 parent_MM;
	glm::mat4 child_MM; 
	Material* cur_material;
	flag_valid = true;

	for (int i = 0; i < N_SPIDER_FRAMES; i++) {
		object_frames.emplace_back();
		sprintf(object_frames[i].filename, "Data/dynamic_objects/spider/spider_vnt_%d%d.geom", i / 10, i % 10);
		object_frames[i].n_fields = 8;
		object_frames[i].front_face_mode = GL_CW;
		object_frames[i].prepare_geom_of_static_object();

		object_frames[i].instances.emplace_back();
		parent_MM = glm::mat4(1.0f); // �ʱ�ȭ
		parent_MM = glm::translate(parent_MM, glm::vec3(220.0f, 0.0f, -25.0f));
		parent_MM = glm::rotate(parent_MM, -90.0f * TO_RADIAN, glm::vec3(1.0f, 0.0f, 0.0f));
		parent_MM = glm::scale(parent_MM, glm::vec3(15.0f));

		object_frames[i].instances.back().ModelMatrix = parent_MM;
		cur_material = &(object_frames[i].instances.back().material);
		cur_material->emission = glm::vec4(128.0f, 0.0f, 128.0f, 1.0f);
		cur_material->ambient = glm::vec4(128.0f, 0.0f, 128.0f, 1.0f);
		cur_material->diffuse = glm::vec4(128.0f, 0.0f, 128.0f, 1.0f);
		cur_material->specular = glm::vec4(128.0f, 0.0f, 128.0f, 1.0f);
		cur_material->exponent = 128.0f * 0.21794872f;

		for (int j = 0; j < 360; j += 30) {
			object_frames[i].instances.emplace_back();

			child_MM = glm::rotate(parent_MM, glm::radians((float)j), glm::vec3(0.0f, 1.0f, 0.0f));
			child_MM = glm::translate(child_MM, glm::vec3(3.0f, 0.0f, 0.0f));
			child_MM = glm::scale(child_MM, glm::vec3(0.5f));  // �ڽ��� ���� ũ���

			object_frames[i].instances.back().ModelMatrix = child_MM;

			cur_material = &(object_frames[i].instances.back().material);
			cur_material->emission = glm::vec4(200.0f, 0.0f, 200.0f, 1.0f);  // �� �� ���� �����
			cur_material->ambient = glm::vec4(200.0f, 0.0f, 200.0f, 1.0f);
			cur_material->diffuse = glm::vec4(200.0f, 0.0f, 200.0f, 1.0f);
			cur_material->specular = glm::vec4(200.0f, 0.0f, 200.0f, 1.0f);
			cur_material->exponent = 64.0f;
		}
	}
}


void Man::define_object() {
#define N_WOLF_FRAMES 16
	glm::mat4* cur_MM;
	Material* cur_material;
	flag_valid = true;

	for (int i = 0; i < N_WOLF_FRAMES; i++) {
		object_frames.emplace_back();

		sprintf(object_frames[i].filename, "Data/dynamic_objects/wolf/wolf_%d%d_vnt.geom", i / 10, i % 10);
		object_frames[i].n_fields = 8;
		object_frames[i].front_face_mode = GL_CW;
		object_frames[i].prepare_geom_of_static_object();

		object_frames[i].instances.emplace_back();
		cur_MM = &(object_frames[i].instances.back().ModelMatrix);
		cur_material = &(object_frames[i].instances.back().material);
		cur_material->emission = glm::vec4(0.0f, 0.0f, 0.0f, 1.0f);
		cur_material->ambient = glm::vec4(0.0f, 0.0f, 0.0f, 1.0f);
		cur_material->diffuse = glm::vec4(0.0f, 0.0f, 0.0f, 1.0f);
		cur_material->specular = glm::vec4(0.0f, 0.0f, 0.0f, 1.0f);
		cur_material->exponent = 128.0f * 0.21794872f;
	}
}

void Wolf_D::define_object() {
#define N_WOLF_FRAMES 16
	glm::mat4* cur_MM;
	Material* cur_material;
	flag_valid = true;

	for (int i = 0; i < N_WOLF_FRAMES; i++) {
		object_frames.emplace_back();
		sprintf(object_frames[i].filename, "Data/dynamic_objects/wolf/wolf_%d%d_vnt.geom", i / 10, i % 10);
		object_frames[i].n_fields = 8;
		object_frames[i].front_face_mode = GL_CW;
		object_frames[i].prepare_geom_of_static_object();

		object_frames[i].instances.emplace_back();
		cur_MM = &(object_frames[i].instances.back().ModelMatrix);
		*cur_MM = glm::rotate(*cur_MM, -30.0f * TO_RADIAN, glm::vec3(0.0f,1.0f,0.0f));
		*cur_MM = glm::scale(*cur_MM, glm::vec3(10.0f));
		cur_material = &(object_frames[i].instances.back().material);
		cur_material->emission = glm::vec4(0.0f, 255.0f, 0.0f, 1.0f);
		cur_material->ambient = glm::vec4(0.0f, 255.0f, 0.0f, 1.0f);
		cur_material->diffuse = glm::vec4(0.0f, 255.0f, 0.0f, 1.0f);
		cur_material->specular = glm::vec4(0.0f, 255.0f, 0.0f, 1.0f);
		cur_material->exponent = 128.0f * 0.21794872f;
	}
}

void Dynamic_Object::draw_object(glm::mat4& ViewMatrix, glm::mat4& ProjectionMatrix, SHADER_ID shader_kind,
	std::vector<std::reference_wrapper<Shader>>& shader_list, int time_stamp) {
	int cur_object_index = time_stamp % object_frames.size();
	Static_Object& cur_object = object_frames[cur_object_index];
	glFrontFace(cur_object.front_face_mode);

	float rotation_angle = 0.0f;
	glm::mat4 ModelMatrix = glm::mat4(1.0f);

	if (object_id == DYNAMIC_OBJECT_SPIDER) {
		Spider_D* spider = static_cast<Spider_D*>(this);
		if (cur_object_index % 6 == 5) {
			spider->angle += 0.7f;
			spider->angle = fmod(spider->angle, 360.0f);
		}
		ModelMatrix = glm::translate(ModelMatrix, glm::vec3(80.0f, -70.0f, 0.0f));
		ModelMatrix = glm::rotate(ModelMatrix, spider->angle * TO_RADIAN, glm::vec3(0.0f, 1.0f, 0.0f));
		ModelMatrix = glm::translate(ModelMatrix, glm::vec3(0.0f, 0.0f, 15.0f));
	}
	if (object_id == EXTRA_SPIDER) {
		Extra_Spider* spider = static_cast<Extra_Spider*>(this);
		spider->angle += 1.0f;
		spider->angle = fmod(spider->angle, 360.0f);
		ModelMatrix = glm::rotate(ModelMatrix, spider->angle * TO_RADIAN, glm::vec3(0.0f, 0.0f, 1.0f));
	}
	if (object_id == EXTRA_MAN) {
		Man* man = static_cast<Man*>(this);

		Camera* target_camera = nullptr;
		for (auto& cam_ref : man->scene->camera_list) {
			Camera& cam = cam_ref.get();
			if (cam.camera_id == CAMERA_MAN) {
				target_camera = &cam;
				break;
			}
		}

		glm::vec3 U_axis = glm::normalize(target_camera->cam_view.uaxis);
		glm::vec3 V_axis = glm::normalize(target_camera->cam_view.vaxis);
		glm::vec3 N_axis = glm::normalize(target_camera->cam_view.naxis);
		glm::vec3 position = target_camera->cam_view.pos;

		glm::mat4 tmp = glm::lookAt(position, position + N_axis, V_axis);
		ModelMatrix = glm::inverse(tmp);
		//ModelMatrix = glm::rotate(glm::mat4(1.0f), 30.0f * TO_RADIAN, glm::vec3(0.0f, 1.0f, 0.0f)) * ModelMatrix;
		
		ModelMatrix = glm::translate(ModelMatrix, glm::vec3(0.0, 0.0f, -3.0f));
		ModelMatrix = glm::scale(ModelMatrix, glm::vec3(30.0f));
		
	}
	if (object_id == DYNAMIC_OBJECT_WOLF) {
		Wolf_D* tiger = static_cast<Wolf_D*>(this);

		const std::vector<glm::vec2> spider_path = {
			{-70, -62}, {-50, -62}, {-40, -40},
			{-40, 0}, {-20, 18},
			
			{60, 15},{50, 15},
  
			{-20, 18},{-40, 5},
			{-40, -40},{-50, -62}, {-70, -62}
		};
		const int TicksPerSegment = 50;
		int n_path_points = spider_path.size();
		int total_ticks = TicksPerSegment * n_path_points;
		int current_tick = time_stamp % total_ticks;
		int segment_index = current_tick / TicksPerSegment;
		float segment_progress = (float)(current_tick % TicksPerSegment) / TicksPerSegment;

		glm::vec2 p0 = spider_path[(segment_index - 1 + n_path_points) % n_path_points];
		glm::vec2 p1 = spider_path[segment_index];
		glm::vec2 p2 = spider_path[(segment_index + 1) % n_path_points];
		glm::vec2 p3 = spider_path[(segment_index + 2) % n_path_points];
		glm::vec2 current_pos_2d = catmullRom(p0, p1, p2, p3, segment_progress);

		float next_progress = segment_progress + 0.1f;
		glm::vec2 next_pos_2d = catmullRom(p0, p1, p2, p3, next_progress);
		glm::vec2 direction = glm::normalize(next_pos_2d - current_pos_2d);
		float angle = atan2(direction.y, direction.x);


		ModelMatrix = glm::translate(ModelMatrix, glm::vec3(current_pos_2d.x, current_pos_2d.y, -25.0f));
		ModelMatrix = glm::rotate(ModelMatrix, angle, glm::vec3(0.0f, 0.0f, 1.0f));

	}

	for (int i = 0; i < cur_object.instances.size(); i++) {
		glm::mat4 ModelViewProjectionMatrix = ProjectionMatrix * ViewMatrix * ModelMatrix * cur_object.instances[i].ModelMatrix;
		switch (shader_kind) {
		case SHADER_SIMPLE:
			Shader_Simple* shader_simple_ptr = static_cast<Shader_Simple*>(&shader_list[shader_ID_mapper[shader_kind]].get());
			glUseProgram(shader_simple_ptr->h_ShaderProgram);
			glUniformMatrix4fv(shader_simple_ptr->loc_ModelViewProjectionMatrix, 1, GL_FALSE,
				&ModelViewProjectionMatrix[0][0]);
			glUniform3f(shader_simple_ptr->loc_primitive_color, cur_object.instances[i].material.diffuse.r,
				cur_object.instances[i].material.diffuse.g, cur_object.instances[i].material.diffuse.b);
			break;
		}
		glBindVertexArray(cur_object.VAO);
		glDrawArrays(GL_TRIANGLES, 0, 3 * cur_object.n_triangles);
		glBindVertexArray(0);
		glUseProgram(0);
	}
}
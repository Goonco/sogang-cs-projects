#define _CRT_SECURE_NO_WARNINGS
#include "Scene_Definitions.h"
#include <glm/gtc/matrix_inverse.hpp>

glm::vec2 catmullRom(const glm::vec2& p0, const glm::vec2& p1, const glm::vec2& p2, const glm::vec2& p3, float t) {
	float t2 = t * t;
	float t3 = t2 * t;
	return 0.5f * ((2.0f * p1) +
		(-p0 + p2) * t +
		(2.0f * p0 - 5.0f * p1 + 4.0f * p2 - p3) * t2 +
		(-p0 + 3.0f * p1 - 3.0f * p2 + p3) * t3);
}

void My_Polygon::define_object() {
	flag_valid = true;
	is_transparent = false;
	opacity = 0.5f; // �ʱ� ��������
	rotation_angle = 0.0f;

	const float PHI = 1.61803398875f;
	std::vector<glm::vec3> p(20);
	p[0] = glm::vec3(1, 1, 1);       p[1] = glm::vec3(1, 1, -1);
	p[2] = glm::vec3(1, -1, 1);      p[3] = glm::vec3(1, -1, -1);
	p[4] = glm::vec3(-1, 1, 1);      p[5] = glm::vec3(-1, 1, -1);
	p[6] = glm::vec3(-1, -1, 1);     p[7] = glm::vec3(-1, -1, -1);
	p[8] = glm::vec3(0, PHI, 1 / PHI); p[9] = glm::vec3(0, PHI, -1 / PHI);
	p[10] = glm::vec3(0, -PHI, 1 / PHI); p[11] = glm::vec3(0, -PHI, -1 / PHI);
	p[12] = glm::vec3(1 / PHI, 0, PHI); p[13] = glm::vec3(-1 / PHI, 0, PHI);
	p[14] = glm::vec3(1 / PHI, 0, -PHI); p[15] = glm::vec3(-1 / PHI, 0, -PHI);
	p[16] = glm::vec3(PHI, 1 / PHI, 0); p[17] = glm::vec3(PHI, -1 / PHI, 0);
	p[18] = glm::vec3(-PHI, 1 / PHI, 0); p[19] = glm::vec3(-PHI, -1 / PHI, 0);
	int faces[12][5] = { /* ... */ };
	faces[0][0] = 0; faces[0][1] = 8; faces[0][2] = 9; faces[0][3] = 1; faces[0][4] = 16;
	faces[1][0] = 0; faces[1][1] = 12; faces[1][2] = 13; faces[1][3] = 4; faces[1][4] = 8;
	faces[2][0] = 0; faces[2][1] = 16; faces[2][2] = 17; faces[2][3] = 2; faces[2][4] = 12;
	faces[3][0] = 1; faces[3][1] = 9; faces[3][2] = 5; faces[3][3] = 18; faces[3][4] = 14;
	faces[4][0] = 1; faces[4][1] = 14; faces[4][2] = 3; faces[4][3] = 17; faces[4][4] = 16;
	faces[5][0] = 2; faces[5][1] = 10; faces[5][2] = 11; faces[5][3] = 3; faces[5][4] = 17;
	faces[6][0] = 2; faces[6][1] = 12; faces[6][2] = 13; faces[6][3] = 6; faces[6][4] = 10;
	faces[7][0] = 3; faces[7][1] = 11; faces[7][2] = 7; faces[7][3] = 15; faces[7][4] = 14;
	faces[8][0] = 4; faces[8][1] = 13; faces[8][2] = 6; faces[8][3] = 19; faces[8][4] = 18;
	faces[9][0] = 4; faces[9][1] = 18; faces[9][2] = 5; faces[9][3] = 9; faces[9][4] = 8;
	faces[10][0] = 5; faces[10][1] = 18; faces[10][2] = 19; faces[10][3] = 7; faces[10][4] = 15;
	faces[11][0] = 6; faces[11][1] = 10; faces[11][2] = 11; faces[11][3] = 7; faces[11][4] = 19;

	std::vector<GLfloat> vertex_data;
	vertex_data.reserve(108 * 6);

	for (int i = 0; i < 12; i++) {
		glm::vec3 v0 = p[faces[i][0]];
		glm::vec3 v1 = p[faces[i][1]];
		glm::vec3 v2 = p[faces[i][2]];
		glm::vec3 v3 = p[faces[i][3]];
		glm::vec3 v4 = p[faces[i][4]];

		glm::vec3 normal = glm::normalize(v0 + v1 + v2 + v3 + v4);

		vertex_data.insert(vertex_data.end(), { v0.x, v0.y, v0.z, normal.x, normal.y, normal.z });
		vertex_data.insert(vertex_data.end(), { v1.x, v1.y, v1.z, normal.x, normal.y, normal.z });
		vertex_data.insert(vertex_data.end(), { v2.x, v2.y, v2.z, normal.x, normal.y, normal.z });

		vertex_data.insert(vertex_data.end(), { v0.x, v0.y, v0.z, normal.x, normal.y, normal.z });
		vertex_data.insert(vertex_data.end(), { v2.x, v2.y, v2.z, normal.x, normal.y, normal.z });
		vertex_data.insert(vertex_data.end(), { v3.x, v3.y, v3.z, normal.x, normal.y, normal.z });

		vertex_data.insert(vertex_data.end(), { v0.x, v0.y, v0.z, normal.x, normal.y, normal.z });
		vertex_data.insert(vertex_data.end(), { v3.x, v3.y, v3.z, normal.x, normal.y, normal.z });
		vertex_data.insert(vertex_data.end(), { v4.x, v4.y, v4.z, normal.x, normal.y, normal.z });
	}

	GLuint VBO_id, VAO_id;
	int n_bytes_per_vertex = 6 * sizeof(GLfloat);

	glGenBuffers(1, &VBO_id);
	glBindBuffer(GL_ARRAY_BUFFER, VBO_id);
	glBufferData(GL_ARRAY_BUFFER, vertex_data.size() * sizeof(GLfloat), vertex_data.data(), GL_STATIC_DRAW);

	glGenVertexArrays(1, &VAO_id);
	glBindVertexArray(VAO_id);
	glBindBuffer(GL_ARRAY_BUFFER, VBO_id);

	glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, n_bytes_per_vertex, BUFFER_OFFSET(0));
	glEnableVertexAttribArray(0);
	glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, n_bytes_per_vertex, BUFFER_OFFSET(3 * sizeof(float)));
	glEnableVertexAttribArray(1);

	glBindVertexArray(0);

#define N_POL_FRAME 1
	object_frames.resize(N_POL_FRAME);

	for (int i = 0; i < N_POL_FRAME; i++) {
		object_frames[i].VBO = VBO_id;
		object_frames[i].VAO = VAO_id;
		object_frames[i].n_triangles = 36;
		object_frames[i].n_fields = 6;
		object_frames[i].front_face_mode = GL_CCW;
		object_frames[i].flag_valid = true;

		object_frames[i].instances.emplace_back();
		glm::mat4& cur_MM = object_frames[i].instances.back().ModelMatrix;
		cur_MM = glm::scale(glm::mat4(1.0), glm::vec3(15.0f));

		Material& cur_material = object_frames[i].instances.back().material;
		cur_material.ambient = glm::vec4(0.1745f, 0.01175f, 0.01175f, 1.0f);
		cur_material.diffuse = glm::vec4(0.61424f, 0.04136f, 0.04136f, 1.0f);
		cur_material.specular = glm::vec4(0.72811f, 0.626959f, 0.626959f, 1.0f);
		cur_material.emission = glm::vec4(0.0f, 0.0f, 0.0f, 1.0f);
		cur_material.exponent = 64.0f;
	}
}

void Spider_D::define_object() {
#define N_SPIDER_FRAMES 16
	glm::mat4* cur_MM;
	Material* cur_material;
	flag_valid = true;

	for (int i = 0; i < N_SPIDER_FRAMES; i++) {
		object_frames.emplace_back();
		sprintf(object_frames[i].filename, "Data/dynamic_objects/spider/spider_vnt_%d%d.geom", i / 10, i % 10);
		object_frames[i].n_fields = 8;
		object_frames[i].front_face_mode = GL_CW;
		object_frames[i].prepare_geom_of_static_object();

		object_frames[i].instances.emplace_back();
		cur_MM = &(object_frames[i].instances.back().ModelMatrix);
		//*cur_MM = glm::rotate(*cur_MM, 90.0f * TO_RADIAN,glm::vec3(0.0f, 1.0f, 0.0f));
		//*cur_MM = glm::scale(*cur_MM, glm::vec3(3.0f, -3.0f, 3.0f));
		cur_material = &(object_frames[i].instances.back().material);
		cur_material->emission = glm::vec4(255.0f, 0.0f, 0.0f, 1.0f);
		cur_material->ambient = glm::vec4(255.0f, 0.0f, 0.0f, 1.0f);
		cur_material->diffuse = glm::vec4(255.0f, 0.0f, 0.0f, 1.0f);
		cur_material->specular = glm::vec4(255.0f, 0.0f, 0.0f, 1.0f);
		cur_material->exponent = 128.0f * 0.21794872f;
	}
}

void Extra_Spider::define_object() {
#define N_SPIDER_FRAMES 16
	glm::mat4 parent_MM;
	glm::mat4 child_MM; 
	Material* cur_material;
	flag_valid = true;

	for (int i = 0; i < N_SPIDER_FRAMES; i++) {
		object_frames.emplace_back();
		sprintf(object_frames[i].filename, "Data/dynamic_objects/spider/spider_vnt_%d%d.geom", i / 10, i % 10);
		object_frames[i].n_fields = 8;
		object_frames[i].front_face_mode = GL_CW;
		object_frames[i].prepare_geom_of_static_object();

		object_frames[i].instances.emplace_back();
		parent_MM = glm::mat4(1.0f); // �ʱ�ȭ
		parent_MM = glm::translate(parent_MM, glm::vec3(220.0f, 0.0f, -25.0f));
		parent_MM = glm::rotate(parent_MM, -90.0f * TO_RADIAN, glm::vec3(1.0f, 0.0f, 0.0f));
		parent_MM = glm::scale(parent_MM, glm::vec3(15.0f));

		object_frames[i].instances.back().ModelMatrix = parent_MM;
		cur_material = &(object_frames[i].instances.back().material);
		cur_material->emission = glm::vec4(128.0f, 0.0f, 128.0f, 1.0f);
		cur_material->ambient = glm::vec4(128.0f, 0.0f, 128.0f, 1.0f);
		cur_material->diffuse = glm::vec4(128.0f, 0.0f, 128.0f, 1.0f);
		cur_material->specular = glm::vec4(128.0f, 0.0f, 128.0f, 1.0f);
		cur_material->exponent = 128.0f * 0.21794872f;

		for (int j = 0; j < 360; j += 30) {
			object_frames[i].instances.emplace_back();

			child_MM = glm::rotate(parent_MM, glm::radians((float)j), glm::vec3(0.0f, 1.0f, 0.0f));
			child_MM = glm::translate(child_MM, glm::vec3(3.0f, 0.0f, 0.0f));
			child_MM = glm::scale(child_MM, glm::vec3(0.5f));

			object_frames[i].instances.back().ModelMatrix = child_MM;

			cur_material = &(object_frames[i].instances.back().material);
			cur_material->emission = glm::vec4(200.0f, 0.0f, 200.0f, 1.0f);
			cur_material->ambient = glm::vec4(200.0f, 0.0f, 200.0f, 1.0f);
			cur_material->diffuse = glm::vec4(200.0f, 0.0f, 200.0f, 1.0f);
			cur_material->specular = glm::vec4(200.0f, 0.0f, 200.0f, 1.0f);
			cur_material->exponent = 64.0f;
		}
	}
}


void Man::define_object() {
#define N_WOLF_FRAMES 16
	glm::mat4* cur_MM;
	Material* cur_material;
	flag_valid = true;

	for (int i = 0; i < N_WOLF_FRAMES; i++) {
		object_frames.emplace_back();

		sprintf(object_frames[i].filename, "Data/dynamic_objects/wolf/wolf_%d%d_vnt.geom", i / 10, i % 10);
		object_frames[i].n_fields = 8;
		object_frames[i].front_face_mode = GL_CW;
		object_frames[i].prepare_geom_of_static_object();

		object_frames[i].instances.emplace_back();
		cur_MM = &(object_frames[i].instances.back().ModelMatrix);
		cur_material = &(object_frames[i].instances.back().material);
		cur_material->emission = glm::vec4(0.0f, 0.0f, 0.0f, 1.0f);
		cur_material->ambient = glm::vec4(0.0f, 0.0f, 0.0f, 1.0f);
		cur_material->diffuse = glm::vec4(0.0f, 0.0f, 0.0f, 1.0f);
		cur_material->specular = glm::vec4(0.0f, 0.0f, 0.0f, 1.0f);
		cur_material->exponent = 128.0f * 0.21794872f;
	}
}

void Wolf_D::define_object() {
#define N_WOLF_FRAMES 16
	glm::mat4* cur_MM;
	Material* cur_material;
	flag_valid = true;

	for (int i = 0; i < N_WOLF_FRAMES; i++) {
		object_frames.emplace_back();
		sprintf(object_frames[i].filename, "Data/dynamic_objects/wolf/wolf_%d%d_vnt.geom", i / 10, i % 10);
		object_frames[i].n_fields = 8;
		object_frames[i].front_face_mode = GL_CW;
		object_frames[i].prepare_geom_of_static_object();

		object_frames[i].instances.emplace_back();
		cur_MM = &(object_frames[i].instances.back().ModelMatrix);
		*cur_MM = glm::rotate(*cur_MM, 180.0f * TO_RADIAN, glm::vec3(0.0f, 0.0f, 1.0f));
		*cur_MM = glm::rotate(*cur_MM, 90.0f * TO_RADIAN, glm::vec3(1.0f,0.0f,0.0f));
		*cur_MM = glm::scale(*cur_MM, glm::vec3(10.0f));
		cur_material = &(object_frames[i].instances.back().material);
		cur_material->emission = glm::vec4(0.0f, 255.0f, 0.0f, 1.0f);
		cur_material->ambient = glm::vec4(0.0f, 255.0f, 0.0f, 1.0f);
		cur_material->diffuse = glm::vec4(0.0f, 255.0f, 0.0f, 1.0f);
		cur_material->specular = glm::vec4(0.0f, 255.0f, 0.0f, 1.0f);
		cur_material->exponent = 128.0f * 0.21794872f;
	}
}

void render_single_frame(glm::mat4& ViewMatrix, glm::mat4& ProjectionMatrix,
	std::vector<std::reference_wrapper<Shader>>& shader_list, Static_Object& cur_object,
	const glm::mat4& final_model_matrix, int flag, float opacity) {

	glm::mat4 ModelViewMatrix = ViewMatrix * final_model_matrix;
	glm::mat4 ModelViewProjectionMatrix = ProjectionMatrix * ModelViewMatrix;
	glm::mat3 ModelViewMatrixInvTrans = glm::inverseTranspose(glm::mat3(ModelViewMatrix));

	Shader_Phong* shader_ptr = static_cast<Shader_Phong*>(&shader_list[shader_ID_mapper[SHADER_PHONG]].get());
	glUseProgram(shader_ptr->h_ShaderProgram);
	glUniform1i(shader_ptr->loc_flag_blending, flag);
	glUniform1f(shader_ptr->loc_fragment_alpha, opacity);

	// ��� ����
	glUniformMatrix4fv(shader_ptr->loc_ModelViewProjectionMatrix, 1, GL_FALSE, &ModelViewProjectionMatrix[0][0]);
	glUniformMatrix4fv(shader_ptr->loc_ModelViewMatrix_PS, 1, GL_FALSE, &ModelViewMatrix[0][0]);
	glUniformMatrix3fv(shader_ptr->loc_ModelViewMatrixInvTrans_PS, 1, GL_FALSE, &ModelViewMatrixInvTrans[0][0]);

	glUniform4fv(shader_ptr->loc_material.ambient_color, 1, &cur_object.instances[0].material.ambient[0]);
	glUniform4fv(shader_ptr->loc_material.diffuse_color, 1, &cur_object.instances[0].material.diffuse[0]);
	glUniform4fv(shader_ptr->loc_material.specular_color, 1, &cur_object.instances[0].material.specular[0]);
	glUniform4fv(shader_ptr->loc_material.emissive_color, 1, &cur_object.instances[0].material.emission[0]);
	glUniform1f(shader_ptr->loc_material.specular_exponent, cur_object.instances[0].material.exponent);

	glUniform1i(shader_ptr->loc_u_wave_flag, shader_ptr->wave_flag);
	glUniform1i(shader_ptr->loc_u_pulse_flag, shader_ptr->pulse_flag);
	
	glBindVertexArray(cur_object.VAO);
	glDrawArrays(GL_TRIANGLES, 0, 3 * cur_object.n_triangles);
	glBindVertexArray(0);
	glUseProgram(0);
}

void Dynamic_Object::draw_object(glm::mat4& ViewMatrix, glm::mat4& ProjectionMatrix, SHADER_ID shader_kind,
	std::vector<std::reference_wrapper<Shader>>& shader_list, int time_stamp) {
	int cur_object_index = time_stamp % object_frames.size();
	Static_Object& cur_object = object_frames[cur_object_index];
	glFrontFace(cur_object.front_face_mode);

	float rotation_angle = 0.0f;
	glm::mat4 ModelMatrix = glm::mat4(1.0f);

	if (object_id == DYNAMIC_OBJECT_SPIDER) {
		Spider_D* spider = static_cast<Spider_D*>(this);
		if (cur_object_index % 6 == 5) {
			spider->angle += 0.7f;
			spider->angle = fmod(spider->angle, 360.0f);
		}
		ModelMatrix = glm::translate(ModelMatrix, glm::vec3(80.0f, -70.0f, 0.0f));
		ModelMatrix = glm::rotate(ModelMatrix, spider->angle * TO_RADIAN, glm::vec3(0.0f, 1.0f, 0.0f));
		ModelMatrix = glm::translate(ModelMatrix, glm::vec3(0.0f, 0.0f, 15.0f));
	}
	if (object_id == EXTRA_SPIDER) {
		Extra_Spider* spider = static_cast<Extra_Spider*>(this);
		spider->angle += 1.0f;
		spider->angle = fmod(spider->angle, 360.0f);
		ModelMatrix = glm::rotate(ModelMatrix, spider->angle * TO_RADIAN, glm::vec3(0.0f, 0.0f, 1.0f));
	}
	/*if (object_id == DYNAMIC_OBJECT_POLYGON) {
		My_Polygon* p = static_cast<My_Polygon*>(this);
		p->rotation_angle += 1.0f;
		p->rotation_angle = fmod(p->rotation_angle, 360.0f);
	
		ModelMatrix = glm::translate(glm::mat4(1.0f), glm::vec3(0.0f, -150.0f, 0.0f));
		ModelMatrix = glm::rotate(ModelMatrix, p->rotation_angle * TO_RADIAN, glm::vec3(0.0f, 0.0f, 1.0f));
	}*/
	if (object_id == EXTRA_MAN) {
		Man* man = static_cast<Man*>(this);

		Camera* target_camera = nullptr;
		for (auto& cam_ref : man->scene->camera_list) {
			Camera& cam = cam_ref.get();
			if (cam.camera_id == CAMERA_MAN) {
				target_camera = &cam;
				break;
			}
		}

		glm::vec3 U_axis = glm::normalize(target_camera->cam_view.uaxis);
		glm::vec3 V_axis = glm::normalize(target_camera->cam_view.vaxis);
		glm::vec3 N_axis = glm::normalize(target_camera->cam_view.naxis);
		glm::vec3 position = target_camera->cam_view.pos;

		glm::mat4 tmp = glm::lookAt(position, position + N_axis, V_axis);
		ModelMatrix = glm::inverse(tmp);
		//ModelMatrix = glm::rotate(glm::mat4(1.0f), 30.0f * TO_RADIAN, glm::vec3(0.0f, 1.0f, 0.0f)) * ModelMatrix;
		
		ModelMatrix = glm::translate(ModelMatrix, glm::vec3(0.0, 0.0f, -3.0f));
		ModelMatrix = glm::scale(ModelMatrix, glm::vec3(30.0f));
		
	}
	if (object_id == DYNAMIC_OBJECT_WOLF) {
		Wolf_D* wolf = static_cast<Wolf_D*>(this);

		const std::vector<glm::vec2> spider_path = {
			{-70, -62}, {-50, -62}, {-40, -40},
			{-40, 0}, {-20, 18},
			
			{60, 15},{50, 15},
  
			{-20, 18},{-40, 5},
			{-40, -40},{-50, -62}, {-70, -62}
		};
		const int TicksPerSegment = 50;
		int n_path_points = spider_path.size();
		int total_ticks = TicksPerSegment * n_path_points;
		int current_tick = time_stamp % total_ticks;
		int segment_index = current_tick / TicksPerSegment;
		float segment_progress = (float)(current_tick % TicksPerSegment) / TicksPerSegment;

		glm::vec2 p0 = spider_path[(segment_index - 1 + n_path_points) % n_path_points];
		glm::vec2 p1 = spider_path[segment_index];
		glm::vec2 p2 = spider_path[(segment_index + 1) % n_path_points];
		glm::vec2 p3 = spider_path[(segment_index + 2) % n_path_points];
		glm::vec2 current_pos_2d = catmullRom(p0, p1, p2, p3, segment_progress);

		float next_progress = segment_progress + 0.1f;
		glm::vec2 next_pos_2d = catmullRom(p0, p1, p2, p3, next_progress);
		glm::vec2 direction = glm::normalize(next_pos_2d - current_pos_2d);
		float angle = atan2(direction.y, direction.x);

		ModelMatrix = glm::translate(ModelMatrix, glm::vec3(current_pos_2d.x, current_pos_2d.y, -25.0f));
		ModelMatrix = glm::rotate(ModelMatrix, -90.0f * TO_RADIAN, glm::vec3(0.0f, 0.0f, 1.0f));
		ModelMatrix = glm::rotate(ModelMatrix, angle, glm::vec3(0.0f, 0.0f, 1.0f));

		wolf->world_pos = glm::vec3(ModelMatrix[3]);
		const glm::vec3 local_forward_vector = glm::vec3(0.0f, 1.0f, 0.0f);
		glm::mat3 rotation_matrix = glm::mat3(ModelMatrix);
		wolf->world_dir = glm::normalize(rotation_matrix * local_forward_vector);
	}
	//------------------------------------------------------------------
	if (object_id == DYNAMIC_OBJECT_POLYGON) {
		My_Polygon* p = static_cast<My_Polygon*>(this);
		p->rotation_angle += 1.0f;
		glm::mat4 tmp = glm::translate(glm::mat4(1.0f), glm::vec3(0.0f, -150.0f, 0.0f));
		glm::mat4 rotation_transform = glm::rotate(tmp, p->rotation_angle * TO_RADIAN, glm::vec3(0.0f, 0.0f, 1.0f));
		glm::mat4 static_transform = cur_object.instances[0].ModelMatrix;
		glm::mat4 final_model_matrix = rotation_transform * static_transform;

		GLboolean original_cull_face_enabled;
		glGetBooleanv(GL_CULL_FACE, &original_cull_face_enabled);
		GLint original_cull_face_mode;
		GLboolean original_depth_mask;
		glGetIntegerv(GL_CULL_FACE_MODE, &original_cull_face_mode);
		glGetBooleanv(GL_DEPTH_WRITEMASK, &original_depth_mask);

		if (p->is_transparent) {
			glEnable(GL_BLEND);
			glBlendFunc(GL_ONE, GL_ONE_MINUS_SRC_ALPHA); // ǥ�� ���� ������
			glDepthMask(GL_FALSE); // ���� ���ۿ� ���� ��Ȱ��ȭ
			render_single_frame(ViewMatrix, ProjectionMatrix, shader_list, cur_object, final_model_matrix, 1, p->opacity);

			glEnable(GL_CULL_FACE);
			glCullFace(GL_BACK);
			render_single_frame(ViewMatrix, ProjectionMatrix, shader_list, cur_object, final_model_matrix, 1, p->opacity);
			glCullFace(GL_FRONT);
			render_single_frame(ViewMatrix, ProjectionMatrix, shader_list, cur_object, final_model_matrix, 1, p->opacity);

			glDisable(GL_BLEND);
		}
		else {
			render_single_frame(ViewMatrix, ProjectionMatrix, shader_list, cur_object, final_model_matrix, 0, p->opacity);
		}

		glDepthMask(original_depth_mask); // ���� ���� ���� ����
		if (original_cull_face_enabled) {
			glEnable(GL_CULL_FACE);
			glCullFace(original_cull_face_mode);
		}
		else {
			glDisable(GL_CULL_FACE);
		}

		return;
	}

	//------------------------------------------------------------------
	for (int i = 0; i < cur_object.instances.size(); i++) {
		glm::mat4 ModelVeiwMatrix = ViewMatrix * ModelMatrix * cur_object.instances[i].ModelMatrix;
		glm::mat4 ModelViewProjectionMatrix = ProjectionMatrix * ModelVeiwMatrix;
		
		Shader_Phong* shader_phong_ptr = static_cast<Shader_Phong*>(&shader_list[shader_ID_mapper[SHADER_PHONG]].get());
		glUseProgram(shader_phong_ptr->h_ShaderProgram);

		glm::mat3 ModelViewMatrixInvTrans = glm::inverseTranspose(glm::mat3(ModelVeiwMatrix));

		glUniformMatrix4fv(shader_phong_ptr->loc_ModelViewProjectionMatrix, 1, GL_FALSE, &ModelViewProjectionMatrix[0][0]);
		glUniformMatrix4fv(shader_phong_ptr->loc_ModelViewMatrix_PS, 1, GL_FALSE, &ModelVeiwMatrix[0][0]);
		glUniformMatrix3fv(shader_phong_ptr->loc_ModelViewMatrixInvTrans_PS, 1, GL_FALSE, &ModelViewMatrixInvTrans[0][0]);

		glUniform4fv(shader_phong_ptr->loc_material.ambient_color, 1, &cur_object.instances[i].material.ambient[0]);
		glUniform4fv(shader_phong_ptr->loc_material.diffuse_color, 1, &cur_object.instances[i].material.diffuse[0]);
		glUniform4fv(shader_phong_ptr->loc_material.specular_color, 1, &cur_object.instances[i].material.specular[0]);
		glUniform4fv(shader_phong_ptr->loc_material.emissive_color, 1, &cur_object.instances[i].material.emission[0]);
		glUniform1f(shader_phong_ptr->loc_material.specular_exponent, cur_object.instances[i].material.exponent);

		glUniform1i(shader_phong_ptr->loc_u_wave_flag, shader_phong_ptr->wave_flag);
		glUniform1i(shader_phong_ptr->loc_u_pulse_flag, shader_phong_ptr->pulse_flag);

		glBindVertexArray(cur_object.VAO);
		glDrawArrays(GL_TRIANGLES, 0, 3 * cur_object.n_triangles);
		glBindVertexArray(0);
		glUseProgram(0);
	}
}
#define _CRT_SECURE_NO_WARNINGS

#include "Scene_Definitions.h"

unsigned int static_object_ID_mapper[N_MAX_STATIC_OBJECTS];
unsigned int dynamic_object_ID_mapper[N_MAX_DYNAMIC_OBJECTS];
unsigned int camera_ID_mapper[N_MAX_CAMERAS];
unsigned int shader_ID_mapper[N_MAX_SHADERS];

void Axis_Object::define_axis() {
	glGenBuffers(1, &VBO);

	glBindBuffer(GL_ARRAY_BUFFER, VBO);
	glBufferData(GL_ARRAY_BUFFER, sizeof(vertices_axes), &vertices_axes[0][0], GL_STATIC_DRAW);

	// Initialize vertex array object.
	glGenVertexArrays(1, &VAO);
	glBindVertexArray(VAO);

	glBindBuffer(GL_ARRAY_BUFFER, VBO);
	glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 0, BUFFER_OFFSET(0));

	glEnableVertexAttribArray(0);
	glBindBuffer(GL_ARRAY_BUFFER, 0);
	glBindVertexArray(0);
}

void Axis_Object::draw_axis(Shader_Simple* shader_simple, glm::mat4& ModelMatrix, glm::mat4& ViewMatrix, glm::mat4& ProjectionMatrix) {
#define WC_AXIS_LENGTH	10.0f
	glm::mat4 ModelViewProjectionMatrix = ProjectionMatrix * ViewMatrix * ModelMatrix;

	glUseProgram(shader_simple->h_ShaderProgram);
	glUniformMatrix4fv(shader_simple->loc_ModelViewProjectionMatrix, 1, GL_FALSE, &ModelViewProjectionMatrix[0][0]);

	glBindVertexArray(VAO);
	glUniform3fv(shader_simple->loc_primitive_color, 1, axes_color[0]);
	glDrawArrays(GL_LINES, 0, 2);
	glUniform3fv(shader_simple->loc_primitive_color, 1, axes_color[1]);
	glDrawArrays(GL_LINES, 2, 2);
	glUniform3fv(shader_simple->loc_primitive_color, 1, axes_color[2]);
	glDrawArrays(GL_LINES, 4, 2);
	glBindVertexArray(0);
	glUseProgram(0);
}

void Scene::clock(int clock_id) { // currently one clock
	time_stamp = ++time_stamp % UINT_MAX;
}

void Scene::build_static_world() {
	static_geometry_data.building.define_object();
	static_object_ID_mapper[STATIC_OBJECT_BUILDING] = static_objects.size();
	static_objects.push_back(static_geometry_data.building);

	static_geometry_data.dragon.define_object();
	static_object_ID_mapper[STATIC_OBJECT_DRAGON] = static_objects.size();
	static_objects.push_back(static_geometry_data.dragon);

	static_geometry_data.light.define_object();
	static_object_ID_mapper[STATIC_OBJECT_LIGHT] = static_objects.size();
	static_objects.push_back(static_geometry_data.light);

	static_geometry_data.table.define_object();
	static_object_ID_mapper[STATIC_OBJECT_TABLE] = static_objects.size();
	static_objects.push_back(static_geometry_data.table);

	static_geometry_data.ironman.define_object();
	static_object_ID_mapper[STATIC_OBJECT_IRONMAN] = static_objects.size();
	static_objects.push_back(static_geometry_data.ironman);

	static_geometry_data.bike.define_object();
	static_object_ID_mapper[STATIC_OBJECT_BIKE] = static_objects.size();
	static_objects.push_back(static_geometry_data.bike);

	static_geometry_data.bus.define_object();
	static_object_ID_mapper[STATIC_OBJECT_BUS] = static_objects.size();
	static_objects.push_back(static_geometry_data.bus);

	static_geometry_data.cat.define_object();
	static_object_ID_mapper[STATIC_OBJECT_CAT] = static_objects.size();
	static_objects.push_back(static_geometry_data.cat);
}

void Scene::build_dynamic_world() {
	dynamic_geometry_data.spider_d.define_object();
	dynamic_object_ID_mapper[DYNAMIC_OBJECT_SPIDER] = dynamic_objects.size();
	dynamic_objects.push_back(dynamic_geometry_data.spider_d);

	dynamic_geometry_data.wolf_d.define_object();
	dynamic_object_ID_mapper[DYNAMIC_OBJECT_WOLF] = dynamic_objects.size();
	dynamic_objects.push_back(dynamic_geometry_data.wolf_d);

	dynamic_geometry_data.extra_spider.define_object();
	dynamic_object_ID_mapper[EXTRA_SPIDER] = dynamic_objects.size();
	dynamic_objects.push_back(dynamic_geometry_data.extra_spider);

	dynamic_geometry_data.man.define_object();
	dynamic_object_ID_mapper[EXTRA_MAN] = dynamic_objects.size();
	dynamic_geometry_data.man.scene = this;
	dynamic_objects.push_back(dynamic_geometry_data.man);

	dynamic_geometry_data.polygon.define_object();
	dynamic_object_ID_mapper[DYNAMIC_OBJECT_POLYGON] = dynamic_objects.size();
	dynamic_objects.push_back(dynamic_geometry_data.polygon);

}

void Scene::create_camera_list(int win_width, int win_height, float win_aspect_ratio) {
	camera_list.clear();
	
	// main camera
	camera_data.cam_main.define_camera(win_width, win_height, win_aspect_ratio);
	camera_ID_mapper[CAMERA_MAIN] = camera_list.size();
	camera_list.push_back(camera_data.cam_main);

	// fixed cameras
	camera_data.cam_cc_1.define_camera(win_width, win_height, win_aspect_ratio);
	camera_ID_mapper[CAMERA_CC_1] = camera_list.size();
	camera_list.push_back(camera_data.cam_cc_1);

	camera_data.cam_cc_2.define_camera(win_width, win_height, win_aspect_ratio);
	camera_ID_mapper[CAMERA_CC_2] = camera_list.size();
	camera_list.push_back(camera_data.cam_cc_2);

	camera_data.cam_cc_3.define_camera(win_width, win_height, win_aspect_ratio);
	camera_ID_mapper[CAMERA_CC_3] = camera_list.size();
	camera_list.push_back(camera_data.cam_cc_3);

	// dynamic camera
	camera_data.cam_dyn.define_camera(win_width, win_height, win_aspect_ratio);
	camera_ID_mapper[CAMERA_DYNAMIC] = camera_list.size();
	camera_list.push_back(camera_data.cam_dyn);

	// ortho cameras
	camera_data.cam_front_side.define_camera(win_width, win_height, win_aspect_ratio);
	camera_ID_mapper[CAMERA_FRONT_SIDE] = camera_list.size();
	camera_list.push_back(camera_data.cam_front_side);

	camera_data.cam_side.define_camera(win_width, win_height, win_aspect_ratio);
	camera_ID_mapper[CAMERA_SIDE] = camera_list.size();
	camera_list.push_back(camera_data.cam_side);

	camera_data.cam_top.define_camera(win_width, win_height, win_aspect_ratio);
	camera_ID_mapper[CAMERA_TOP] = camera_list.size();
	camera_list.push_back(camera_data.cam_top);

	// extra
	camera_data.cam_man.define_camera(win_width, win_height, win_aspect_ratio);
	camera_ID_mapper[CAMERA_MAN] = camera_list.size();
	camera_list.push_back(camera_data.cam_man);
}

void Scene::build_shader_list() {
	shader_data.shader_simple.prepare_shader();
	shader_ID_mapper[SHADER_SIMPLE] = shader_list.size();
	shader_list.push_back(shader_data.shader_simple);

	shader_data.shader_phong.prepare_shader();
	shader_ID_mapper[SHADER_PHONG] = shader_list.size();
	shader_list.push_back(shader_data.shader_phong);

	shader_data.shader_gouraud.prepare_shader();
	shader_ID_mapper[SHADER_GOURAUD] = shader_list.size();
	shader_list.push_back(shader_data.shader_gouraud);
}

void Scene::initialize() {
	axis_object.define_axis();
	build_static_world();
	build_dynamic_world();
	create_camera_list(window.width, window.height, window.aspect_ratio);
	build_shader_list();
	initialize_lights();
	
}

void Scene::draw_static_world() {
	glm::mat4 ModelViewProjectionMatrix;
	for (auto static_object = static_objects.begin(); static_object != static_objects.end(); static_object++) {
		if (static_object->get().flag_valid == false) continue;
		static_object->get().draw_object(ViewMatrix, ProjectionMatrix, shader_kind, shader_list, time_stamp);
	}
}

void Scene::draw_dynamic_world() {
	glm::mat4 ModelViewProjectionMatrix;
	for (auto dynamic_object = dynamic_objects.begin(); dynamic_object != dynamic_objects.end(); dynamic_object++) {
		if (dynamic_object->get().flag_valid == false) continue;
		dynamic_object->get().draw_object(ViewMatrix, ProjectionMatrix, shader_kind, shader_list, time_stamp);
	}
}

void Scene::draw_axis() {
	glm::mat4 ModelMatrix = glm::scale(glm::mat4(1.0f), glm::vec3(WC_AXIS_LENGTH, WC_AXIS_LENGTH, WC_AXIS_LENGTH));
	axis_object.draw_axis(static_cast<Shader_Simple*>(&shader_list[shader_ID_mapper[SHADER_SIMPLE]].get()), ModelMatrix,
		ViewMatrix, ProjectionMatrix);
}

void Scene::draw_camera_frames() {
	for (const auto& cam_ref : camera_list) {
		const Camera& cam = cam_ref.get();
		if (cam.cam_proj.projection_type == CAMERA_PROJECTION_ORTHOGRAPHIC) continue;

		glm::mat4 model_matrix(1.0f);
		model_matrix[0] = glm::vec4(cam.cam_view.uaxis, 0.0f); 
		model_matrix[1] = glm::vec4(cam.cam_view.vaxis, 0.0f); 
		model_matrix[2] = glm::vec4(cam.cam_view.naxis, 0.0f); 
		model_matrix[3] = glm::vec4(cam.cam_view.pos, 1.0f);

		float axis_length = 20.0f;
		model_matrix = model_matrix * glm::scale(glm::mat4(1.0f), glm::vec3(axis_length));

		axis_object.draw_axis(static_cast<Shader_Simple*>(&shader_list[shader_ID_mapper[SHADER_SIMPLE]].get()),
			model_matrix, ViewMatrix, ProjectionMatrix);
	}
}


void Scene::draw_world() {
	set_lights();
	draw_axis();
	draw_static_world();
	draw_dynamic_world();
	draw_camera_frames();
}

void Scene::initialize_lights() {
	for (int i = 0; i < NUMBER_OF_LIGHT_SUPPORTED; ++i) {
		light[i].light_on = 0;
		light[i].position[0] = 0.0f; light[i].position[1] = 0.0f; light[i].position[2] = 1.0f; light[i].position[3] = 1.0f;
		light[i].ambient_color[0] = 0.0f; light[i].ambient_color[1] = 0.0f; light[i].ambient_color[2] = 0.0f; light[i].ambient_color[3] = 1.0f;
		light[i].diffuse_color[0] = 0.0f; light[i].diffuse_color[1] = 0.0f; light[i].diffuse_color[2] = 0.0f; light[i].diffuse_color[3] = 1.0f;
		light[i].specular_color[0] = 0.0f; light[i].specular_color[1] = 0.0f; light[i].specular_color[2] = 0.0f; light[i].specular_color[3] = 1.0f;
		light[i].spot_cutoff_angle = 180.0f;
		light[i].spot_exponent = 0.0f;

	}

	// ���� ��ǥ�� spot light
	light[0].position[0] = 0.0f; light[0].position[1] = 0.0f;light[0].position[2] = 80.0f; light[0].position[3] = 1.0f;
	light[0].ambient_color[0] = 0.2f; light[0].ambient_color[1] = 0.2f; light[0].ambient_color[2] = 0.2f; light[0].ambient_color[3] = 1.0f;
	light[0].diffuse_color[0] = 0.82f; light[0].diffuse_color[1] = 0.82f;light[0].diffuse_color[2] = 0.82f; light[0].diffuse_color[3] = 1.0f;
	light[0].specular_color[0] = 0.82f; light[0].specular_color[1] = 0.82f;light[0].specular_color[2] = 0.82f; light[0].specular_color[3] = 1.0f;
	light[0].spot_direction[0] = 0.0f; light[0].spot_direction[1] = 0.0f;light[0].spot_direction[2] = -1.0f;
	light[0].spot_cutoff_angle = 20.0f;light[0].spot_exponent = 27.0f;

	// ���� ���� ����
	light[1].light_on = 1;
	light[1].position[0] = 0.0f; light[1].position[1] = 0.0f; light[1].position[2] = 100.0f; light[1].position[3] = 0.0f;
	light[1].ambient_color[0] = 0.2f; light[1].ambient_color[1] = 0.2f; light[1].ambient_color[2] = 0.2f;
	light[1].diffuse_color[0] = 0.4f; light[1].diffuse_color[1] = 0.4f; light[1].diffuse_color[2] = 0.4f;
	light[1].specular_color[0] = 0.4f; light[1].specular_color[1] = 0.4f; light[1].specular_color[2] = 0.4f;
	light[4].light_on = 1;
	light[4].position[0] = 0.0f; light[4].position[1] = 0.0f; light[4].position[2] = -100.0f; light[4].position[3] = 0.0f;
	light[4].ambient_color[0] = 0.2f; light[4].ambient_color[1] = 0.2f; light[4].ambient_color[2] = 0.2f;
	light[4].diffuse_color[0] = 0.4f; light[4].diffuse_color[1] = 0.4f; light[4].diffuse_color[2] = 0.4f;
	light[4].specular_color[0] = 0.4f; light[4].specular_color[1] = 0.4f; light[4].specular_color[2] = 0.4f;

	// ī�޶� ����
	light[2].position[0] = 0.0f; light[2].position[1] = 0.0f; light[2].position[2] = 0.0f; light[2].position[3] = 1.0f;
	light[2].ambient_color[0] = 0.0f; light[2].ambient_color[1] = 0.0f; light[2].ambient_color[2] = 0.0f;
	light[2].diffuse_color[0] = 1.0f; light[2].diffuse_color[1] = 1.0f; light[2].diffuse_color[2] = 1.0f;
	light[2].specular_color[0] = 1.0f; light[2].specular_color[1] = 1.0f; light[2].specular_color[2] = 1.0f;
	light[2].spot_direction[0] = 0.0f; light[2].spot_direction[1] = 0.0f; light[2].spot_direction[2] = -1.0f;
	light[2].spot_cutoff_angle = 40.0f; light[2].spot_exponent = 1.0f;
	light[2].light_attenuation_factors[0] = 0.05f;
	light[2].light_attenuation_factors[1] = 0.01f;
	light[2].light_attenuation_factors[2] = 0.0f;
	light[2].light_attenuation_factors[3] = 0.01f;

	// ���� ����
	light[3].ambient_color[0] = 0.0f;light[3].ambient_color[1] = 0.0f;light[3].ambient_color[2] = 0.0f;light[3].ambient_color[3] = 0.0f;
	light[3].diffuse_color[0] = 0.3f;light[3].diffuse_color[1] = 0.3f;light[3].diffuse_color[2] = 0.3f;light[3].diffuse_color[3] = 0.3f;
	light[3].specular_color[0] = 1.0f;light[3].specular_color[1] = 1.0f;light[3].specular_color[2] = 1.0f;light[3].specular_color[3] = 1.0f;
	light[3].spot_cutoff_angle = 180.0f;
	light[3].light_attenuation_factors[0] = 0.3f;
	light[3].light_attenuation_factors[1] = 0.007f;
	light[3].light_attenuation_factors[2] = 0.0002f;
	light[3].light_attenuation_factors[3] = 1.0f;
}

template<typename T_Shader>
void set_lights_for_shader(T_Shader* shader, const glm::mat4& view_matrix, const Light_Parameters* lights) {
	glUseProgram(shader->h_ShaderProgram);
	glUniform4f(shader->loc_global_ambient_color, 0.3f, 0.3f, 0.3f, 1.0f);

	for (int i = 0; i < NUMBER_OF_LIGHT_SUPPORTED; i++) {
		glUniform1i(shader->loc_light[i].light_on, lights[i].light_on);
		if (!lights[i].light_on) continue;

		glm::vec4 position_in_eye_space;
		glm::vec3 direction_in_eye_space;
		glm::vec4 light_pos(lights[i].position[0], lights[i].position[1], lights[i].position[2], lights[i].position[3]);
		
		if (i == 2) {
			position_in_eye_space = glm::vec4(0.0f, 0.0f, 0.0f, 1.0f);
			direction_in_eye_space = glm::vec3(lights[i].spot_direction[0], lights[i].spot_direction[1], lights[i].spot_direction[2]);
		}
		else { 
			position_in_eye_space = view_matrix * light_pos;
			direction_in_eye_space = glm::mat3(view_matrix) * glm::vec3(lights[i].spot_direction[0], lights[i].spot_direction[1], lights[i].spot_direction[2]);
		}

		glUniform4fv(shader->loc_light[i].position, 1, &position_in_eye_space[0]);

		glUniform4fv(shader->loc_light[i].ambient_color, 1, lights[i].ambient_color);
		glUniform4fv(shader->loc_light[i].diffuse_color, 1, lights[i].diffuse_color);
		glUniform4fv(shader->loc_light[i].specular_color, 1, lights[i].specular_color);
		glUniform3fv(shader->loc_light[i].spot_direction, 1, &direction_in_eye_space[0]);
		glUniform1f(shader->loc_light[i].spot_exponent, lights[i].spot_exponent);
		glUniform1f(shader->loc_light[i].spot_cutoff_angle, lights[i].spot_cutoff_angle);
		glUniform4fv(shader->loc_light[i].light_attenuation_factors, 1, lights[i].light_attenuation_factors);
	}
}

void Scene::set_lights() {
	Wolf_D* wolf_ptr = static_cast<Wolf_D*>(&dynamic_objects[DYNAMIC_OBJECT_WOLF].get());
	light[3].position[0] = wolf_ptr->world_pos.x;
	light[3].position[1] = wolf_ptr->world_pos.y;
	light[3].position[2] = wolf_ptr->world_pos.z;

	/*static int frame_counter = 0;
	if (frame_counter % 60 == 0) {
		printf("--- [Frame: %d] Wolf Light Debug ---\n", this->time_stamp);
		printf("  Wolf Position: [%.2f, %.2f, %.2f]\n",
			wolf_ptr->world_pos.x,
			wolf_ptr->world_pos.y,
			wolf_ptr->world_pos.z);
		printf("  Wolf Direction: [%.2f, %.2f, %.2f]\n",
			wolf_ptr->world_dir.x,
			wolf_ptr->world_dir.y,
			wolf_ptr->world_dir.z);
	}
	frame_counter++;*/


	Shader_Phong* shader_phong_ptr = static_cast<Shader_Phong*>(&shader_list[shader_ID_mapper[SHADER_PHONG]].get());
	set_lights_for_shader(shader_phong_ptr, this->ViewMatrix, this->light);

	Shader_Gouraud* shader_gouraud_ptr = static_cast<Shader_Gouraud*>(&shader_list[shader_ID_mapper[SHADER_GOURAUD]].get());
	set_lights_for_shader(shader_gouraud_ptr, this->ViewMatrix, this->light);

	glUseProgram(0);
}
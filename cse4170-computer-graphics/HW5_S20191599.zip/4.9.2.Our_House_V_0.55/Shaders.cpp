#define _CRT_SECURE_NO_WARNINGS

#include "Scene_Definitions.h"

void Shader_Simple::prepare_shader() {
	shader_info[0] = { GL_VERTEX_SHADER, "Shaders/simple.vert" };
	shader_info[1] = { GL_FRAGMENT_SHADER, "Shaders/simple.frag" };
	shader_info[2] = { GL_NONE, NULL };

	h_ShaderProgram = LoadShaders(shader_info);
	glUseProgram(h_ShaderProgram);

	loc_ModelViewProjectionMatrix = glGetUniformLocation(h_ShaderProgram, "u_ModelViewProjectionMatrix");
	loc_primitive_color = glGetUniformLocation(h_ShaderProgram, "u_primitive_color");
	glUseProgram(0);
}

void Shader_Phong::prepare_shader() {
	shader_info[0] = { GL_VERTEX_SHADER, "Shaders/Phong_sc.vert" };
	shader_info[1] = { GL_FRAGMENT_SHADER, "Shaders/Phong_sc.frag" };
	shader_info[2] = { GL_NONE, NULL };
	h_ShaderProgram = LoadShaders(shader_info);
	
	glUseProgram(h_ShaderProgram);

	loc_ModelViewProjectionMatrix = glGetUniformLocation(h_ShaderProgram, "u_ModelViewProjectionMatrix");
	loc_ModelViewMatrix_PS = glGetUniformLocation(h_ShaderProgram, "u_ModelViewMatrix");
	loc_ModelViewMatrixInvTrans_PS = glGetUniformLocation(h_ShaderProgram, "u_ModelViewMatrixInvTrans");
	
	loc_u_time = glGetUniformLocation(h_ShaderProgram, "u_time");
	loc_u_wave_flag = glGetUniformLocation(h_ShaderProgram, "u_wave_flag");
	loc_u_pulse_flag = glGetUniformLocation(h_ShaderProgram, "u_pulse_flag");

	loc_global_ambient_color = glGetUniformLocation(h_ShaderProgram, "u_global_ambient_color");
	loc_flag_blending = glGetUniformLocation(h_ShaderProgram, "u_flag_blending");
	loc_fragment_alpha = glGetUniformLocation(h_ShaderProgram, "u_fragment_alpha");

	loc_material.ambient_color = glGetUniformLocation(h_ShaderProgram, "u_material.ambient_color");
	loc_material.diffuse_color = glGetUniformLocation(h_ShaderProgram, "u_material.diffuse_color");
	loc_material.specular_color = glGetUniformLocation(h_ShaderProgram, "u_material.specular_color");
	loc_material.emissive_color = glGetUniformLocation(h_ShaderProgram, "u_material.emissive_color");
	loc_material.specular_exponent = glGetUniformLocation(h_ShaderProgram, "u_material.specular_exponent");

	char name[128];
	for (int i = 0; i < NUMBER_OF_LIGHT_SUPPORTED; i++) {
		sprintf(name, "u_light[%d].light_on", i);
		loc_light[i].light_on = glGetUniformLocation(h_ShaderProgram, name);
		sprintf(name, "u_light[%d].position", i);
		loc_light[i].position = glGetUniformLocation(h_ShaderProgram, name);
		sprintf(name, "u_light[%d].ambient_color", i);
		loc_light[i].ambient_color = glGetUniformLocation(h_ShaderProgram, name);
		sprintf(name, "u_light[%d].diffuse_color", i);
		loc_light[i].diffuse_color = glGetUniformLocation(h_ShaderProgram, name);
		sprintf(name, "u_light[%d].specular_color", i);
		loc_light[i].specular_color = glGetUniformLocation(h_ShaderProgram, name);
		sprintf(name, "u_light[%d].spot_direction", i);
		loc_light[i].spot_direction = glGetUniformLocation(h_ShaderProgram, name);
		sprintf(name, "u_light[%d].spot_exponent", i);
		loc_light[i].spot_exponent = glGetUniformLocation(h_ShaderProgram, name);
		sprintf(name, "u_light[%d].spot_cutoff_angle", i);
		loc_light[i].spot_cutoff_angle = glGetUniformLocation(h_ShaderProgram, name);
		sprintf(name, "u_light[%d].light_attenuation_factors", i);
		loc_light[i].light_attenuation_factors = glGetUniformLocation(h_ShaderProgram, name);
	}

	glUseProgram(0);
}

void Shader_Gouraud::prepare_shader() {
	shader_info[0] = { GL_VERTEX_SHADER, "Shaders/gouraud.vert" };
	shader_info[1] = { GL_FRAGMENT_SHADER, "Shaders/gouraud.frag" };
	shader_info[2] = { GL_NONE, NULL };
	h_ShaderProgram = LoadShaders(shader_info);

	glUseProgram(h_ShaderProgram);

	loc_ModelViewProjectionMatrix = glGetUniformLocation(h_ShaderProgram, "u_ModelViewProjectionMatrix");
	loc_ModelViewMatrix_GS = glGetUniformLocation(h_ShaderProgram, "u_ModelViewMatrix");
	loc_ModelViewMatrixInvTrans_GS = glGetUniformLocation(h_ShaderProgram, "u_ModelViewMatrixInvTrans");

	loc_global_ambient_color = glGetUniformLocation(h_ShaderProgram, "u_global_ambient_color");

	loc_material.ambient_color = glGetUniformLocation(h_ShaderProgram, "u_material.ambient_color");
	loc_material.diffuse_color = glGetUniformLocation(h_ShaderProgram, "u_material.diffuse_color");
	loc_material.specular_color = glGetUniformLocation(h_ShaderProgram, "u_material.specular_color");
	loc_material.emissive_color = glGetUniformLocation(h_ShaderProgram, "u_material.emissive_color");
	loc_material.specular_exponent = glGetUniformLocation(h_ShaderProgram, "u_material.specular_exponent");

	char name[128];
	for (int i = 0; i < NUMBER_OF_LIGHT_SUPPORTED; i++) {
		sprintf(name, "u_light[%d].light_on", i);
		loc_light[i].light_on = glGetUniformLocation(h_ShaderProgram, name);
		sprintf(name, "u_light[%d].position", i);
		loc_light[i].position = glGetUniformLocation(h_ShaderProgram, name);
		sprintf(name, "u_light[%d].ambient_color", i);
		loc_light[i].ambient_color = glGetUniformLocation(h_ShaderProgram, name);
		sprintf(name, "u_light[%d].diffuse_color", i);
		loc_light[i].diffuse_color = glGetUniformLocation(h_ShaderProgram, name);
		sprintf(name, "u_light[%d].specular_color", i);
		loc_light[i].specular_color = glGetUniformLocation(h_ShaderProgram, name);
		sprintf(name, "u_light[%d].spot_direction", i);
		loc_light[i].spot_direction = glGetUniformLocation(h_ShaderProgram, name);
		sprintf(name, "u_light[%d].spot_exponent", i);
		loc_light[i].spot_exponent = glGetUniformLocation(h_ShaderProgram, name);
		sprintf(name, "u_light[%d].spot_cutoff_angle", i);
		loc_light[i].spot_cutoff_angle = glGetUniformLocation(h_ShaderProgram, name);
		sprintf(name, "u_light[%d].light_attenuation_factors", i);
		loc_light[i].light_attenuation_factors = glGetUniformLocation(h_ShaderProgram, name);
	}

	glUseProgram(0);
}